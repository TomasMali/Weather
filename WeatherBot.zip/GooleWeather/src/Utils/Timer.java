package Utils;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.telegram.telegrambots.api.objects.Update;

import Jsoup.Query;
import Weather.MyWeather;

public class Timer extends Thread {
	String citta = "";
	Update update = new Update();
	MyWeather instant = new MyWeather();
	public boolean running = false;
	User current = null;
	long hour = 3600000;
	long tempo = 0;
	long duration = hour * 12;

	public Timer(String citta, Update update, MyWeather instant, User current, long tempo) {
		this.citta = citta;
		this.update = update;
		this.instant = instant;
		this.current = current;
		this.tempo = tempo;
	}

	public void run() {
		while (running) {
			System.out.println("Sto stampando");
			try {
				current.composeMessage(Query.getWeather(citta, "METEO"));
			} catch (IOException e1) {
				current.composeMessage("Città non trovata!");
				e1.printStackTrace();
			}
			try {

				String str = "07:03:10 am";
				DateFormat formatter = new SimpleDateFormat("hh:mm:ss a");
				// try {
				// Date date = formatter.parse(str);
				// duration = date.getTime();
				// } catch (ParseException e) {
				//
				// e.printStackTrace();
				// }

				Thread.sleep(duration);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
