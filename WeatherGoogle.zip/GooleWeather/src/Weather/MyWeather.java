package Weather;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;

import Jsoup.Query;
import Utils.User;
import Utils.Utils;





	
	

public class MyWeather extends TelegramLongPollingBot  {
//	public MyWeatherData myweatherData = null;
	private List<User> list = new ArrayList<User>();

	
	@Override
	public String getBotToken() {
		return "601333146:AAHJ4Fa1wDt5x5Tsm2bB7CQE1qhYAEXxyBM";
	}


	public String getBotUsername() {
		return "tomasweather";
	//	tomasmalibot
	//	502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw
    //  TomasSubitoBot
	//  657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0
		
	}

	@Override
	public void onUpdateReceived(Update update) {
		
		User current = new User(this,update);
		if(!Utils.checkUser(current, list))
			list.add(current);
		
//		
//		
//		if (update.hasMessage())
//			HasMessage(update);
//		else if (update.hasCallbackQuery())
//			HasCallbackQuery(update);
		
		if (update.hasMessage()) {
			 if (update.getMessage().hasText()) {
				 String meteo = update.getMessage().getText();
				boolean previsione = false;
				if( meteo.contains("#")){
					 meteo = meteo.substring(1);
					 if(meteo.contains("#")) { // previsione
						 meteo = meteo.substring(1);
						 previsione = true;
					 }
					try {
						current.composeMessage(Query.getWeather(meteo,previsione));
					} catch (IOException e) {
						System.out.println("Citta non trovata!");
						e.printStackTrace();
					}
				}
				 
			 }
		}
		else 
			if (update.hasCallbackQuery()) {
			
		}
		
		
	}
	
	
	
}
