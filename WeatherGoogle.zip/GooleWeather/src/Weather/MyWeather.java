package Weather;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.telegram.telegrambots.api.objects.Update;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;

import Jsoup.Query;
import Utils.Timer;
import Utils.User;
import Utils.Utils;

public class MyWeather extends TelegramLongPollingBot {
	// public MyWeatherData myweatherData = null;
	private List<User> list = new ArrayList<User>();
	User current = null;
	String todo = "";

	@Override
	public String getBotToken() {
		return "601333146:AAHJ4Fa1wDt5x5Tsm2bB7CQE1qhYAEXxyBM";
	}

	public String getBotUsername() {
		return "tomasweather";
		// tomasmalibot
		// 502596920:AAGXj1omTxPldCElns1Wiw965LqslMSKBHw
		// TomasSubitoBot
		// 657809545:AAEA4xHiTKLndDuRJc9G5XYrwt-ul2WFqH0
		// tomasweather
		// 601333146:AAHJ4Fa1wDt5x5Tsm2bB7CQE1qhYAEXxyBM

	}

	@Override
	public void onUpdateReceived(Update update) {

		current = new User(this, update);
		if (!Utils.checkUser(current, list))
			list.add(current);

		if (update.hasMessage())
			hasMessage(update);
		else if (update.hasCallbackQuery())
			HasCallbackQuery(update);

	}

	public void hasMessage(Update update) {
		if (update.getMessage().hasText()) {
			String meteo = update.getMessage().getText();
			boolean previsione = false;
			try {
				current = Utils.getUser(update.getMessage().getChat().getId(), list);
				if (meteo.contains("###")) { // il caso delle notifiche
					meteo = meteo.substring(3);
					if (current.running == false) {
						current.setCitta(meteo);
						current.timer = new Timer(meteo, update, this, current, 10);
						current.timer.running = true;
						current.running = true;
						current.timer.start();
						current.composeMessage("Hai attivato le notifiche!");
						return;
					} else
						current.composeMessage("Hai già attivato le notifiche per : " + current.getCitta()
								+ " Scrivere: 'TIMEROFF' per disabilitarlo");
					return;
				} else if (meteo.contains("##")) { // il caso della previsione settimanale
					todo = "PREVISIONE";
					meteo = meteo.substring(2);
					current.composeMessage(Query.getWeather(meteo, todo));
					return;
				} else if (meteo.contains("#")) {
					todo = "METEO";
					meteo = meteo.substring(1);
					current.composeMessage(Query.getWeather(meteo, todo));
					return;
				} else if (meteo.toUpperCase().contains("/START")) {
					current.composeMessage("COSA PUO' FARE QUESTO BOT:" + "\n" + "\n"
							+ "1) Può controllare il meteo per oggi digitando #nomecittà" + "\n"
							+ "2) Può effettuare una previsione settimanale digitando ##nomecittà \n"
							+ "3) Può inviarti notifiche ogni giorno per il meteo giornaliero digitando ###nomecittà");
					return;
				} else if (meteo.toUpperCase().contains("TIMEROFF")) {
					if (current.running == true) {
						current.timer.running = false;
						current.running = false;
						current.composeMessage("Non riceverai più notifiche da questo Bot!");
						return;
					} else
						current.composeMessage("Non hai ancora attivato le notifiche, premi /Start per attivarle");
					return;
				}

				else
					current.composeMessage(
							"Commando non riconosciuto! Clickare /Start per andare nella pagina principale.");

			} catch (IOException e) {
				System.out.println("Citta non trovata!");
				e.printStackTrace();
			}
		}
	}

	public void HasCallbackQuery(Update update) {

	}

}
