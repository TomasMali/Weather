package Utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.telegram.telegrambots.api.objects.Update;

import Jsoup.Query;
import Weather.MyWeather;

public class Timer extends Thread {
	String citta = "";
	Update update = new Update();
	MyWeather instant = new MyWeather();
	public boolean running = false;
	User current = null;
	long hour = 3600000;
	long tempo = 0;
	double tot = 0;
	NotificaOra notificaOra = null;

	public Timer(String citta, Update update, MyWeather instant, User current, long tempo) {
		this.citta = citta;
		this.update = update;
		this.instant = instant;
		this.current = current;
		this.tempo = tempo;
	}

	public void run() {
		notificaOra = new NotificaOra(citta, update, instant, current);
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
		String str = sdf.format(new Date());
		double nowH = Double.parseDouble(str.substring(0, 2));
		double nowM = Double.parseDouble(str.substring(3, 5));

		int stopH = 7;
		int stopM = 30;

		if (nowH < stopH)
			tot = stopH - nowH;
		else if (stopH < nowH)
			tot = (24 - nowH) + stopH;
		else
			tot = 0;

		if (stopM > nowM)
			tot = tot + (stopM - nowM) / 60;
		else if (stopM < nowM) {
			if (tot > (nowM - stopM) / 60)
				tot = tot - (nowM - stopM) / 60;
			else if (tot < (nowM - stopM) / 60)
				tot = 24 - (nowM - stopM) / 60;
		}

		tot = tot * (3600000);
		long s = (long) tot;

		while (running) {
			System.out.println("Sto stampando");
			try {
				current.composeMessage(Query.getWeather(citta, "METEO"));
			} catch (IOException e1) {
				current.composeMessage("Città non trovata!");
				e1.printStackTrace();
			}
			try {
				if (!notificaOra.isAlive()) {
					notificaOra.start();
					notificaOra.running = true;
				}
				Thread.sleep(s);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
