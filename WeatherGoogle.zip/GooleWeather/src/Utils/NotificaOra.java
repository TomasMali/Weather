package Utils;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.telegram.telegrambots.api.objects.Update;

import Jsoup.Query;
import Weather.MyWeather;

public class NotificaOra extends Thread {

	String citta = "";
	Update update = new Update();
	MyWeather instant = new MyWeather();
	public boolean running = false;
	User current = null;
	long hour = 3600000;
	boolean giaNotificato = false;

	public NotificaOra(String citta, Update update, MyWeather instant, User current) {
		this.citta = citta;
		this.update = update;
		this.instant = instant;
		this.current = current;

	}

	public void run() {
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");

		while (running) {
			String str = sdf.format(new Date());
			long nowH = Long.parseLong(str.substring(0, 2)) + 1;
			long nowM = Long.parseLong(str.substring(3, 5));
			try {
				// qui bisogna fare i controlli per ogni ora
				String result = Query.getOre(citta, "METEO", Long.toString(nowH));
				if (result != null && !giaNotificato) {
					giaNotificato = true;
					current.composeMessage(result);
				} else {
					// current.composeMessage("Meteo");
					giaNotificato = false;
				}
			} catch (IOException e1) {
				current.composeMessage("Problema Server Telegram!");
				e1.printStackTrace();
			}
			try {
				if (nowH - 1 == 21)
					running = false;
				else
					Thread.sleep((60 - nowM) * 60000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
