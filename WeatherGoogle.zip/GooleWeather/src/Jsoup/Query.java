package Jsoup;

import java.io.IOException;

import java.net.URLEncoder;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Query {
	private static String HARDSUN  = "\ud83c\udf1e"; 
	private static String CLEARSKY  = "\u2600\ufe0f";    
	private static String SERENO  = "\ud83c\udf1b";
	private static String FEWCLOUDS  = "\u26c5\ufe0f";  
	private static String SCATTEREDCLOUDS  = "\ud83c\udf25";   
	private static String SHOWERRAIN  = "\ud83c\udf26";   
	private static String RAIN  = "\u2614\ufe0f";   
	private static String THUNDERSTORM  = "\u26a1\ufe0f";    
	private static String SNOW  = "\u2744\ufe0f";    
	
    public static String getWeather(String citta, boolean previsione) throws IOException {
        StringBuilder query = new StringBuilder();

     
        Document      doc2   = Jsoup.connect("https://www.ilmeteo.it/meteo/" + citta + "/previsioni-orarie").get();

       Element iframe = doc2.select("iframe#frmprevi").first();
       String iframeSrc = iframe.attr("src");
       Element table = null;
       if(iframeSrc != null) {
       Document    iframeContentDoc = Jsoup.connect(iframeSrc).get();
        table = iframeContentDoc.select("table").first();
       
       }
       
       
       Elements rows = table.select("tr");

       for (int i = 4; i < rows.size(); i++) { //first row is the col names so skip it.
           Element row = rows.get(i);
           
         
          System.out.println("Ore: " + (i==4 ? "Adesso" : row.select("td span.ora").text() + ":00")); 
          System.out.println("#################" + "\n");
          System.out.println("Cielo: " +row.select("td.col3").text() + getIcon(row.select("td.col3").text())); 
          System.out.println("Temp: "+row.select("td span.boldval").text() + "\n"); 
          
         query.append("Ore: " + (i==4 ? "Adesso" : row.select("td span.ora").text() + ":00") + "\n"); 
         query.append("Cielo: " + row.select("td.col3").text() +  getIcon(row.select("td.col3").text())+ "\n"); 
         query.append( "Temp: " + row.select("td span.boldval").text() + "\n");
         if(i==4)
         query.append("\n"+"#################");
         query.append("\n");
           
        
       }
       


        return query.toString();
    }
    
    private static String getIcon(String meteo) {
    	String icon = "";
    	if(meteo.contains("sole e caldo"))
    		return HARDSUN;
    	if(meteo.contains("sole"))
    		return CLEARSKY;
    	if(meteo.contains("nubi") || meteo.contains("poco nuvoloso") )
    		return FEWCLOUDS;
    	if(meteo.contains("coperto"))
    		return SCATTEREDCLOUDS;
    	if(meteo.contains("pioggia "))    
    		return RAIN;
    	if(meteo.contains("temporale"))
    	return	THUNDERSTORM;    
    	
    	if(meteo.contains("sereno"))
        	return	SERENO;
    	
    	return SNOW;
    }
    
}


//~ Formatted by Jindent --- http://www.jindent.com
