package Jsoup;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Query {
	private static String HARDSUN = "\ud83c\udf1e";
	private static String CLEARSKY = "\u2600\ufe0f";
	private static String SERENO = "\ud83c\udf1b";
	private static String FEWCLOUDS = "\u26c5\ufe0f";
	private static String SCATTEREDCLOUDS = "\ud83c\udf25";
	private static String SHOWERRAIN = "\ud83c\udf26";
	private static String RAIN = "\u2614\ufe0f";
	private static String THUNDERSTORM = "\u26a1\ufe0f";
	private static String SNOW = "\u2744\ufe0f";

	public static String getWeather(String citta, String todo) throws IOException {
		Document doc = Jsoup.connect("https://www.ilmeteo.it/meteo/" + citta + "/previsioni-orarie").get();

		if (todo.equals("METEO"))
			return getMeteo(citta, todo, doc);
		else
			return getPrevisione(citta, todo, doc);

	}

	public static String getOre(String citta, String todo, String ore) throws IOException {
		Document doc = Jsoup.connect("https://www.ilmeteo.it/meteo/" + citta + "/previsioni-orarie").get();

		StringBuilder query = new StringBuilder();

		Element iframe = doc.select("iframe#frmprevi").first();
		String iframeSrc = iframe.attr("src");
		Element table = null;
		if (iframeSrc != null) {
			Document iframeContentDoc = Jsoup.connect(iframeSrc).get();
			table = iframeContentDoc.select("table").first();

		}

		Elements rows = table.select("tr");
		boolean trovato = false;

		for (int i = 4; i < rows.size() && !trovato; i++) { // first row is the col names so skip it.
			Element row = rows.get(i); // contains(ore)

			String hour = row.select("td span.ora").text().substring(0, 2).trim();
			hour = hour.substring(0, 1).trim().equals("0") ? hour.substring(1, 2).trim() : hour;

			if (hour.equals(ore.trim())) {

				System.out.println("Ore: " + row.select("td span.ora").text() + ":00");
				System.out.println("#################" + "\n");
				System.out.println("Cielo: " + row.select("td.col3").text() + getIcon(row.select("td.col3").text()));
				System.out.println("Temp: " + row.select("td span.boldval").text() + "\n");

				query.append("Ore: " + (i == 4 ? "Adesso" : row.select("td span.ora").text() + ":00") + "\n");
				query.append("Cielo: " + row.select("td.col3").text() + getIcon(row.select("td.col3").text()) + "\n");
				query.append("Temp: " + row.select("td span.boldval").text() + "\n\n");
				trovato = true;
			}

		}
		if (query.toString().toUpperCase().contains("pioggia".toUpperCase()) || query.toString().toUpperCase().contains(
				"temporale".toUpperCase())) {
			return "ATTENZIONE  A " + citta.toUpperCase() + "\n" + query.toString();
		}
		return null;

	}

	private static String getPrevisione(String citta, String todo, Document doc) throws IOException {
		// URL url = new URL("https://www.ilmeteo.it/pdf/meteo-dobbiaco.pdf");
		//
		// URLConnection connection = url.openConnection();
		//
		// InputStream input = connection.getInputStream();
		//
		// Document doc = Jsoup.parse(input, null, "UTF-8");
		// System.out.println(doc.toString());

		StringBuilder query = new StringBuilder();

		Element iframe = doc.select("iframe#frmprevi").first();
		String iframeSrc = iframe.attr("src");
		Document iframeContentDoc = null;

		if (iframeSrc != null)
			iframeContentDoc = Jsoup.connect(iframeSrc).get();

		Elements li = iframeContentDoc.select("div.scroll > ul > li");

		for (int i = 1; i < li.size() - 1; i++) {

			System.out.println("Giorno: " + li.get(i).select("span").get(0).text() + "\n" + getIcon(li.get(i).select(
					"span").get(1).toString()) + li.get(i).select("span").get(1).toString() + 12345);
			// System.out.println("Temp.Min: " + li.get(i).select("span.tmin").text() + "\n");
			// System.out.println("Icon: " + li.get(i).select("span").get(1).toString());
			// System.out.println("Temp.Max: " + li.get(i).select("span.tmax").text() + "\n");

			query.append("Giorno :" + li.get(i).select("span").get(0).text() + " " + getIcon(li.get(i).select("span")
					.get(1).toString()) + "\n");
			query.append("Temp.Min: " + li.get(i).select("span.tmin").text() + "\n");
			query.append("Temp.Max: " + li.get(i).select("span.tmax").text() + "\n\n");

		}

		return query.toString();
	}
	// #######

	// #######

	// #######

	// #######

	private static String getMeteo(String citta, String todo, Document doc) throws IOException {
		StringBuilder query = new StringBuilder();

		Element iframe = doc.select("iframe#frmprevi").first();
		String iframeSrc = iframe.attr("src");
		Element table = null;
		if (iframeSrc != null) {
			Document iframeContentDoc = Jsoup.connect(iframeSrc).get();
			table = iframeContentDoc.select("table").first();

		}

		Elements rows = table.select("tr");

		for (int i = 4; i < rows.size(); i++) { // first row is the col names so skip it.
			Element row = rows.get(i);

			System.out.println("Ore: " + (i == 4 ? "Adesso" : row.select("td span.ora").text() + ":00"));
			System.out.println("#################" + "\n");
			System.out.println("Cielo: " + row.select("td.col3").text() + getIcon(row.select("td.col3").text()));
			System.out.println("Temp: " + row.select("td span.boldval").text() + "\n");

			query.append("Ore: " + (i == 4 ? "Adesso" : row.select("td span.ora").text() + ":00") + "\n");
			query.append("Cielo: " + row.select("td.col3").text() + getIcon(row.select("td.col3").text()) + "\n");
			query.append("Temp: " + row.select("td span.boldval").text() + "\n");
			if (i == 4)
				query.append("\n" + "#################");
			query.append("\n");

		}

		return query.toString();
	}

	private static String getIcon(String meteo) {
		String icon = "";
		if (meteo.contains("sole e caldo") || meteo.contains("s ss2\""))
			return HARDSUN;
		if (meteo.contains("sole") || meteo.contains("s ss1\""))
			return CLEARSKY;
		if (meteo.contains("nubi") || meteo.contains("poco nuvoloso") || meteo.contains("s ss3\"") || meteo.contains(
				"s ss21\"") || meteo.contains("s ss4\"") || meteo.contains("ss s104\""))
			return FEWCLOUDS;
		if (meteo.contains("coperto") || meteo.contains("foschia") || meteo.contains("s ss8\""))
			return SCATTEREDCLOUDS;
		if (meteo.contains("pioggia") || meteo.contains("s ss5\"") || meteo.contains("s ss110\"") || meteo.contains(
				"s ss105\"") || meteo.contains("s ss23\""))
			return RAIN;
		if (meteo.contains("temporale") || meteo.contains("s ss16\"") || meteo.contains("s ss13\""))
			return THUNDERSTORM;
		if (meteo.contains("sereno") || meteo.contains("s ss101\""))
			return SERENO;

		return "\u2753";
	}

}

// ~ Formatted by Jindent --- http://www.jindent.com
