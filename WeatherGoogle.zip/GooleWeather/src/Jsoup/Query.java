package Jsoup;

import java.io.IOException;

import java.net.URLEncoder;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Query {
    public static String getWeather(String citta, boolean previsione) throws IOException {
        StringBuilder query = new StringBuilder();
        Document      doc   = Jsoup.connect("https://www.google.it/search?&q=meteo+" + citta + "&ie=UTF-8").get();

        
        System.out.println(doc.select("#wob_loc").first().text() + "\n");
        query.append(doc.select("#wob_loc").first().text() + "\n");
        System.out.println(doc.select("#wob_dts").first().text() + "\n");
        query.append(doc.select("#wob_dts").first().text() + "\n");
        System.out.println(doc.select("#wob_dc").first().text() + "\n");
        query.append(doc.select("#wob_dc").first().text() + "\n");
        System.out.println("Temp: " + doc.select("#wob_tm").first().text() + " °C" + "\n");
        query.append("Temp: " + doc.select("#wob_tm").first().text() + " °C" + "\n");
     
        Document      doc2   = Jsoup.connect("https://www.ilmeteo.it/meteo/" + citta + "/previsioni-orarie").get();

       Element iframe = doc2.select("iframe#frmprevi").first();
       String iframeSrc = iframe.attr("src");
       Element table = null;
       if(iframeSrc != null) {
       Document    iframeContentDoc = Jsoup.connect(iframeSrc).get();
        table = iframeContentDoc.select("table").first();
       
       }
       
       
       Elements rows = table.select("tr");

       for (int i = 3; i < rows.size(); i++) { //first row is the col names so skip it.
           Element row = rows.get(i);
          System.out.println(row.select("td span.ora")); 
       }
       
      Elements elementi = doc.select("#wob_dp");
        query.append("###############");
        for(Element el : elementi) {
        	
        	 System.out.println(doc.select("div.vk_lgy.wob_hw").text() + "\n");
             query.append(doc.select("div.vk_lgy wob_hw").first().text() + "\n");
             System.out.println(doc.select("#wob_dc").first().text() + "\n");
             query.append(doc.select("#wob_dc").first().text() + "\n");
             System.out.println("Temp: " + doc.select("#wob_tm").first().text() + " °C" + "\n");
             query.append("Temp: " + doc.select("#wob_tm").first().text() + " °C" + "\n");
        	
        }
        
        
        
        

        return query.toString();
    }
}


//~ Formatted by Jindent --- http://www.jindent.com
